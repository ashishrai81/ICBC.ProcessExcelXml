﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ICBC.ProcessExcelXml;
using ICBC.ProcessExcelXml.Controllers;

namespace ICBC.ProcessExcelXml.Tests.Controllers
{
    [TestClass]
    public class UploadControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            UploadController controller = new UploadController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
