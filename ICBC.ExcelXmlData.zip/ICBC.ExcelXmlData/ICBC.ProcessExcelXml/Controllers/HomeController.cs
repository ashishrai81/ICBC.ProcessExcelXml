﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Aspose.Cells;
using Aspose.Cells.Rendering;
using ICBC.ProcessExcelXml.Helper;
using log4net;
using Excel= Microsoft.Office.Interop.Excel;

namespace ICBC.ProcessExcelXml.Controllers
{
    public class HomeController : Controller
    { 
        public List<Sheet> sheets;
        public string ExcelFile, XmlFile;
        ILog log = log4net.LogManager.GetLogger(typeof(HomeController));

        [HttpGet]
        public ActionResult Index()
        {
            log.Debug("Index");
            ExcelFile = Server.MapPath(Path.Combine("~/Documents", "Report.xlsx"));
            XmlFile = Server.MapPath(Path.Combine("~/Documents", "Report.xml"));
            sheets = new List<Sheet>();
            // Display default Worksheet on page load
            if (System.IO.File.Exists(ExcelFile))
            {
                sheets = RenderExcelWorksheetsAsImage();
            }
            
            return View(sheets);
        }
        public List<Sheet> RenderExcelWorksheetsAsImage()
        {
            // Load the Excel workbook 
            if (System.IO.File.Exists(Server.MapPath(Path.Combine("~/Documents", "Report.xml"))))
            {
                Excel.Application oExcel = new Excel.Application();
                Excel.Workbook WB = oExcel.Workbooks.Open(ExcelFile);
                string xmlData = System.IO.File.ReadAllText(XmlFile);
                WB.XmlMaps["Final_Map"].ImportXml(xmlData, true);
                object misValue = System.Reflection.Missing.Value;
                WB.Close(true, misValue, misValue);
                oExcel.Workbooks.Close();
                oExcel.Quit();
                log.Debug("Merging Report.xml");

            }

            Workbook book = new Workbook(ExcelFile);
            var workSheets = new List<Sheet>();
            ImageOrPrintOptions options = new ImageOrPrintOptions();
            options.HorizontalResolution = 200;
            options.VerticalResolution = 200;
            options.AllColumnsInOnePagePerSheet = true;
            options.OnePagePerSheet = true;
            options.TextCrossType = TextCrossType.Default;
            options.ImageType = Aspose.Cells.Drawing.ImageType.Png;

            string imagePath = "";
            string basePath = Server.MapPath("~/");

            WorkbookRender wr = new WorkbookRender(book, options);
            // Save and view worksheets
            for (int j = 0; j < book.Worksheets.Count; j++)
            {
                imagePath = Path.Combine("/Documents/Rendered", string.Format("sheet_{0}.png", j));
                wr.ToImage(j, basePath + imagePath);
                workSheets.Add(new Sheet { SheetName = string.Format("{0}", book.Worksheets[j].Name), Path = imagePath });
            }

            return workSheets;
    }
}
}