﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using log4net;

namespace ICBC.ProcessExcelXml.Controllers
{
    public class UploadController : Controller
    {
        ILog log = log4net.LogManager.GetLogger(typeof(UploadController));

        // GET: Upload  
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult UploadFile()
        {
            log.Debug("UploadFile");

            return View();
        }
        [HttpPost]
        public ActionResult UploadFile(HttpPostedFileBase[] files)
        {
            try
            {
                foreach (string filePath in Directory.GetFiles(Server.MapPath("~/Documents")))
                {
                    System.IO.File.Delete(filePath);
                }

                foreach (var file in files)
                {
                    if (file.ContentLength > 0)
                    {
                        string _FileExt = Path.GetExtension(file.FileName);
                        string _path = Path.Combine(Server.MapPath("~/Documents"), "Report"+_FileExt);
                        file.SaveAs(_path);
                        log.Debug("Saved: " + _path);
                    }
                }
                
                return RedirectToAction("Index", "Home");
            }
            catch
            {
                ViewBag.Message = "File upload failed!!";
                return View();
            }
        }
    }
}